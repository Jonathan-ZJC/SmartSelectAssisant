import tkinter as tk
import sys
from random import choice
from os import path


def app():
    """
    主程序函数，用于创建和管理 GUI 应用程序。
    """

    # 异常处理
    def wrong(text_):
        """
        显示错误信息的窗口。

        参数:
            text_ (str): 错误信息文本。
        """
        tr_wrong = tk.Tk()
        tr_wrong.geometry('1400x900+0+30')
        tr_wrong.iconbitmap('icon_attention.ico')
        tr_wrong.title('报错')

        # 创建一个框架用于容纳标签，以便更好地控制布局
        tr_wr_frame = tk.Frame(tr_wrong)
        tr_wr_frame.pack(expand=True, fill='both')

        # 将错误信息从“：”处截断
        error_parts = text_.split(':', 1)  # 最多分割一次
        title_part = error_parts[0] + '：'  # 包含“：”的前半部分
        message_part = error_parts[1] if len(error_parts) > 1 else ''  # 后半部分

        # 设置标签的显示位置
        tr_wr_label_1 = tk.Label(tr_wr_frame, text=title_part, font=('楷体', 30, 'bold'))
        tr_wr_label_2 = tk.Label(tr_wr_frame, text=message_part, font=('楷体', 30, 'bold'))
        tr_wr_label_3 = tk.Label(tr_wr_frame, text='请关闭所有窗口&阅读"README-问题处理"', font=('楷体', 25))

        # 使用 grid 方法来控制标签的排列
        tr_wr_label_1.grid(row=0, column=0, sticky="w", pady=(200, 10), padx=10)
        tr_wr_label_2.grid(row=1, column=0, sticky="w", pady=(10, 100), padx=10)
        tr_wr_label_3.grid(row=2, column=0, sticky="w", pady=(10, 20), padx=10)

    # 获取数据文件的绝对路径
    def resource_path(relative_path):
        """
        获取资源文件的绝对路径。

        参数:
            relative_path (str): 相对路径。

        返回:
            str: 绝对路径。
        """
        try:
            # PyInstaller 创建的临时文件夹
            base_path = sys._MEIPASS
        except Exception:
            # 脚本运行的当前路径
            base_path = path.abspath(".")
        return path.join(base_path, relative_path)

    # 保存配置
    def save_configuration():
        """
        保存应用程序的配置到文件中。
        """
        try:
            with open('configuration.txt', 'w', encoding="utf-8") as file:
                file.write(' '.join(names) + '\n')  # 第一行：内容列表
                file.write(str(pass_size) + '\n')  # 第二行：字体大小
                file.write(pass_color + '\n')  # 第三行：普通字体颜色
                file.write(pass_final_color + '\n')  # 第四行：最终字体颜色
                file.write('True' if pass_move else 'False' + '\n')  # 第五行：是否删除
        except Exception as e:
            wrong(f"保存配置时出错: {e}")

    # 读取配置文件函数
    def read_configuration():
        """
        从文件中读取应用程序的配置。
        """
        global names, pass_size, pass_color, pass_final_color, pass_move
        try:
            file_path = resource_path('configuration.txt')
            with open(file_path, 'r', encoding="utf-8") as file:
                # 读取所有行
                lines = file.readlines()

                # 解析内容
                names = lines[0].strip().split()
                pass_size = int(lines[1].strip())
                pass_color = lines[2].strip()
                pass_final_color = lines[3].strip()
                pass_move = lines[4].strip().lower() == 'true'
        except Exception as e:
            wrong(f"读取配置时出错:{e}")
            # 设置默认值
            names = []
            pass_size = 20
            pass_color = 'black'
            pass_final_color = 'blue'
            pass_move = True

    # 全局变量
    l_button_root = []  # 按钮列表
    current_labels = []  # 当前显示的标签列表

    # 读取配置文件
    read_configuration()

    def clear_window():
        """
        清除主窗口中的所有组件。
        """
        # 销毁窗口中的所有子组件
        for widget in root.winfo_children():
            widget.destroy()

    # 是否删除名字
    def remove_name(name_list, name):
        """
        从列表中移除指定的名字。

        参数:
            name_list (list): 名字列表。
            name (str): 要移除的名字。

        返回:
            list: 更新后的名字列表。
        """
        try:
            if pass_move:
                name_list.remove(name)
            return name_list
        except:
            return name_list

    # 随机选择一个名字
    def random_name():
        """
        从名字列表中随机选择一个名字。

        返回:
            str: 随机选择的名字。
        """
        if names:
            return choice(names)
        else:
            return ''

    # 更新标签显示随机名字
    def update_labels(num):
        """
        更新标签以显示随机选择的名字。

        参数:
            num (int): 显示的标签数量。
        """
        # 销毁旧的标签
        for label in current_labels:
            label.destroy()
        current_labels.clear()

        # 创建新的标签用于显示随机名字
        for i in range(num):
            label = tk.Label(root, font=('楷体', pass_size + 25, 'bold'))
            label.place(relx=0.5, rely=(1.0 / (num + 1)) * (i + 1), anchor='center')
            current_labels.append(label)

        # 在显示最终选择之前先变换（5个）名字
        def show_random_names():
            for label in current_labels:
                for _ in range(5):
                    name = random_name()
                    if name:
                        label.config(text=name, fg=pass_color)
                        root.update()
                        root.after(100 + _ * 200)
                    else:
                        break
                # 最终选择的名字
                final_name = random_name()
                if final_name:
                    remove_name(names, final_name)
                    label.config(text=final_name, fg=pass_final_color)
                else:
                    def fun__():
                        clear_window()
                        root_label_complete = tk.Label(root, text='所有内容都循环过了',
                                                       font=('楷体', pass_size + 18, 'bold'))
                        root_label_complete.grid(row=0, column=0, sticky="nsew")
                        root.grid_rowconfigure(0, weight=1)
                        root.grid_columnconfigure(0, weight=1)
                        root.after(2000, lambda: root.destroy())

                    root_button__ = tk.Button(root, text='确定', font=('楷体', pass_size + 4, 'bold'), command=fun__)
                    root_button__.grid(row=10, column=10, sticky='se', padx=10, pady=5)
                    root.update()

        # 使用 after 方法安排 show_random_names 在一定时间后执行
        root.after(200, show_random_names)

    # 创建主窗口
    root = tk.Tk()
    root.geometry('550x600+150+90')
    root.title('随机')
    root.iconbitmap('icon_app.ico')

    # 创建标签组件
    l1 = tk.Label(root, text='选择人数', font=('楷体', pass_size))
    l1.grid(row=1, column=1, pady=10)

    # 创建按钮功能
    def fun1():
        update_labels(1)

    def fun2():
        update_labels(2)

    def fun3():
        update_labels(3)

    def fun4():
        update_labels(4)

    def fun5():
        update_labels(5)

    def fun6():
        update_labels(6)

    # 创建按钮
    for i in range(6):
        btn = tk.Button(root, font=('楷体', pass_size, 'bold'), command=locals()[f'fun{i + 1}'])
        btn.config(text=f'{i + 1}个')
        btn.grid(row=i + 2, column=1)
        l_button_root.append(btn)

    # 创建配置窗口按钮
    _label = tk.Label(root, text='', font=('楷体', pass_size + 10))
    _label.grid(row=8, column=1)

    # 创建配置窗口
    def trunk_set():
        """
        创建配置窗口，并设置其组件。
        """
        try:
            trunk = tk.Toplevel()
            trunk.geometry('500x550+300+180')
            trunk.resizable(False, False)
            trunk.title('配置')
            trunk.iconbitmap('icon_trunk.ico')
        except Exception as e:
            wrong(f"创建配置窗口时出错: {e}")
            return

        l_button_trunk = []

        # 配置内容
        def fun1_tr():
            """
            配置内容窗口的功能。
            """
            try:
                l_trunk_1 = tk.Toplevel()
                l_trunk_1.geometry('370x530+300+150')
                l_trunk_1.resizable(False, False)
                l_trunk_1.title('内容')
                l_trunk_1.iconbitmap('icon_trunk.ico')

                names_now = names.copy()

                def fun1_tr1():
                    """
                    添加名字的功能。
                    """
                    try:
                        l_trunk_1_1 = tk.Toplevel()
                        l_trunk_1_1.geometry('430x270+300+200')
                        l_trunk_1_1.resizable(False, False)
                        l_trunk_1_1.title('内容_添加')
                        l_trunk_1_1.iconbitmap('icon_trunk.ico')

                        tr1_entry_1 = tk.Entry(l_trunk_1_1)
                        tr1_entry_1.grid(row=2, column=1)

                        tr1_label_1 = tk.Label(l_trunk_1_1, text=' ', font=('楷体', pass_size + 2, 'bold'))
                        tr1_label_1.grid(row=1, column=1)

                        def fun1_tr1_1():
                            if tr1_entry_1.get().strip():
                                names_now.append(tr1_entry_1.get().strip())
                                l_trunk_1_1.destroy()
                            else:
                                tr1_label_1.config(text='不能为空！')

                        tr1_1_button_1 = tk.Button(l_trunk_1_1, text='确定', font=('楷体', pass_size, 'bold'),
                                                   command=fun1_tr1_1)
                        tr1_1_button_1.grid(row=4, column=3, sticky='se', padx=15, pady=10)
                    except Exception as e:
                        wrong(f"内容_添加窗口出错: {e}")

                def fun1_tr2():
                    """
                    删除名字的功能。
                    """
                    try:
                        l_trunk_1_2 = tk.Toplevel()
                        l_trunk_1_2.geometry('430x270+300+200')
                        l_trunk_1_2.resizable(False, False)
                        l_trunk_1_2.title('内容_删除')
                        l_trunk_1_2.iconbitmap('icon_trunk.ico')

                        tr1_entry_2 = tk.Entry(l_trunk_1_2)
                        tr1_entry_2.grid(row=2, column=1)

                        tr1_label_1 = tk.Label(l_trunk_1_2, text='', font=('楷体', pass_size + 2, 'bold'))
                        tr1_label_1.grid(row=1, column=1)

                        def fun1_tr1_2():
                            name_to_remove = tr1_entry_2.get().strip()
                            if not name_to_remove:
                                tr1_label_1.config(text='不能为空！')
                            elif name_to_remove not in names_now:
                                tr1_label_1.config(text='此文本不存在！')
                            else:
                                names_now.remove(name_to_remove)
                                l_trunk_1_2.destroy()

                        tr1_2_button_1 = tk.Button(l_trunk_1_2, text='确定', font=('楷体', pass_size, 'bold'),
                                                   command=fun1_tr1_2)
                        tr1_2_button_1.grid(row=4, column=3, sticky='se', padx=15, pady=10)
                    except Exception as e:
                        wrong(f"内容_删除窗口出错: {e}")

                def fun1_tr3():
                    """
                    替换名字列表的功能。
                    """
                    try:
                        l_trunk_1_3 = tk.Toplevel()
                        l_trunk_1_3.geometry('580x360+400+200')
                        l_trunk_1_3.resizable(False, False)
                        l_trunk_1_3.title('内容_替换')
                        l_trunk_1_3.iconbitmap('icon_trunk.ico')

                        tr1_label_1 = tk.Label(l_trunk_1_3, text='文本间用空格隔开',
                                               font=('楷体', pass_size + 2, 'bold'))
                        tr1_label_1.grid(row=1, column=1)
                        tr1_entry_3 = tk.Entry(l_trunk_1_3)
                        tr1_entry_3.grid(row=3, column=1)

                        tr1_label_2 = tk.Label(l_trunk_1_3, text='', font=('楷体', pass_size + 2, 'bold'))
                        tr1_label_2.grid(row=2, column=1)

                        def fun1_tr1_3():
                            new_names = tr1_entry_3.get().strip()
                            if new_names:
                                names_now[:] = new_names.split()
                                l_trunk_1_3.destroy()
                            else:
                                tr1_label_2.config(text='不能为空！')

                        tr1_3_button_1 = tk.Button(l_trunk_1_3, text='确定', font=('楷体', pass_size + 3, 'bold'),
                                                   command=fun1_tr1_3)
                        tr1_3_button_1.grid(row=5, column=3, sticky='se', padx=15, pady=10)
                    except Exception as e:
                        wrong(f"内容_替换窗口出错: {e}")

                tr1_button_1 = tk.Button(l_trunk_1, text='添加', font=('楷体', pass_size + 3, 'bold'), command=fun1_tr1)
                tr1_button_1.grid(row=2, column=1, padx=15, pady=15)
                tr1_button_2 = tk.Button(l_trunk_1, text='删除', font=('楷体', pass_size + 3, 'bold'), command=fun1_tr2)
                tr1_button_2.grid(row=3, column=1, padx=15, pady=15)
                tr1_button_3 = tk.Button(l_trunk_1, text='替换', font=('楷体', pass_size + 3, 'bold'), command=fun1_tr3)
                tr1_button_3.grid(row=4, column=1, padx=15, pady=15)

                def fun4_tr1():
                    global names
                    names = names_now.copy()
                    l_trunk_1.destroy()

                tr1_button_4 = tk.Button(l_trunk_1, text='确定', font=('楷体', pass_size, 'bold'), command=fun4_tr1)
                tr1_button_4.grid(row=6, column=3, sticky='se', padx=25, pady=20)
            except Exception as e:
                wrong(f"内容配置窗口出错: {e}")

        # 配置字体大小
        def fun2_tr():
            """
            配置字体大小的功能。
            """
            try:
                l_trunk_2 = tk.Toplevel()
                l_trunk_2.geometry('500x320+300+150')
                l_trunk_2.resizable(False, False)
                l_trunk_2.title('大小')
                l_trunk_2.iconbitmap('icon_trunk.ico')

                pass_size_now = pass_size

                def change_size(val):
                    new_size = int(val)
                    tr2_label_1.config(font=('楷体', new_size, 'bold'))

                tr2_scale_1 = tk.Scale(l_trunk_2, orient=tk.HORIZONTAL, from_=5, to=35, length=200, label='调节',
                                       command=change_size)
                tr2_scale_1.grid(row=2, column=1)
                tr2_scale_1.set(pass_size)
                tr2_label_1 = tk.Label(l_trunk_2, text='这是个样例', font=('楷体', pass_size, 'bold'))
                tr2_label_1.grid(row=1, column=1)

                def fun1_tr2():
                    global pass_size
                    pass_size = int(tr2_scale_1.get())
                    l_trunk_2.destroy()

                tr2_button_1 = tk.Button(l_trunk_2, text='确定', font=('楷体', pass_size, 'bold'), command=fun1_tr2)
                tr2_button_1.grid(row=5, column=2, sticky='se', padx=20, pady=17)
            except Exception as e:
                wrong(f"字体大小配置窗口出错: {e}")

        # 配置颜色
        def fun3_tr():
            """
            配置颜色的功能。
            """
            try:
                l_trunk_3 = tk.Toplevel()
                l_trunk_3.geometry('1000x540+120+90')
                l_trunk_3.resizable(False, False)
                l_trunk_3.title('颜色')
                l_trunk_3.iconbitmap('icon_trunk.ico')

                tr3_label_1 = tk.Label(l_trunk_3, text='一般：', font=('楷体', pass_size, 'bold'))
                tr3_label_1.grid(row=2, column=1)
                tr3_label_2 = tk.Label(l_trunk_3, text='RGB：', font=('楷体', pass_size))
                tr3_label_2.grid(row=3, column=1)

                def change_color_general(val):
                    r = tr3_scale_1.get()
                    g = tr3_scale_2.get()
                    b = tr3_scale_3.get()
                    tr3_canvas_1.config(bg=f'#{r:02x}{g:02x}{b:02x}')

                tr3_scale_1 = tk.Scale(l_trunk_3, orient=tk.HORIZONTAL, from_=0, to=255, length=255, label='R',
                                       command=change_color_general)
                tr3_scale_1.grid(row=4, column=2)
                tr3_scale_2 = tk.Scale(l_trunk_3, orient=tk.HORIZONTAL, from_=0, to=255, length=255, label='G',
                                       command=change_color_general)
                tr3_scale_2.grid(row=5, column=2)
                tr3_scale_3 = tk.Scale(l_trunk_3, orient=tk.HORIZONTAL, from_=0, to=255, length=255, label='B',
                                       command=change_color_general)
                tr3_scale_3.grid(row=6, column=2)
                tr3_canvas_1 = tk.Canvas(l_trunk_3, bg=pass_color, width=200, height=100)
                tr3_canvas_1.grid(row=8, column=2)

                # 初始化滑块
                if pass_color.startswith('#'):
                    r = int(pass_color[1:3], 16)
                    g = int(pass_color[3:5], 16)
                    b = int(pass_color[5:7], 16)
                    tr3_scale_1.set(r)
                    tr3_scale_2.set(g)
                    tr3_scale_3.set(b)

                tr3_label_3 = tk.Label(l_trunk_3, text='最终：', font=('楷体', pass_size, 'bold'))
                tr3_label_3.grid(row=2, column=4)
                tr3_label_4 = tk.Label(l_trunk_3, text='RGB：', font=('楷体', pass_size))
                tr3_label_4.grid(row=3, column=4)

                def change_color_final(val):
                    r = tr3_scale_4.get()
                    g = tr3_scale_5.get()
                    b = tr3_scale_6.get()
                    tr3_canvas_2.config(bg=f'#{r:02x}{g:02x}{b:02x}')

                tr3_scale_4 = tk.Scale(l_trunk_3, orient=tk.HORIZONTAL, from_=0, to=255, length=255, label='R',
                                       command=change_color_final)
                tr3_scale_4.grid(row=4, column=5)
                tr3_scale_5 = tk.Scale(l_trunk_3, orient=tk.HORIZONTAL, from_=0, to=255, length=255, label='G',
                                       command=change_color_final)
                tr3_scale_5.grid(row=5, column=5)
                tr3_scale_6 = tk.Scale(l_trunk_3, orient=tk.HORIZONTAL, from_=0, to=255, length=255, label='B',
                                       command=change_color_final)
                tr3_scale_6.grid(row=6, column=5)
                tr3_canvas_2 = tk.Canvas(l_trunk_3, bg=pass_final_color, width=200, height=100)
                tr3_canvas_2.grid(row=8, column=5)

                # 初始化滑块
                if pass_final_color.startswith('#'):
                    r = int(pass_final_color[1:3], 16)
                    g = int(pass_final_color[3:5], 16)
                    b = int(pass_final_color[5:7], 16)
                    tr3_scale_4.set(r)
                    tr3_scale_5.set(g)
                    tr3_scale_6.set(b)

                def fun1_tr3():
                    global pass_color, pass_final_color
                    pass_color = tr3_canvas_1['bg']
                    pass_final_color = tr3_canvas_2['bg']
                    l_trunk_3.destroy()

                tr3_button_1 = tk.Button(l_trunk_3, text='确定', font=('楷体', pass_size, 'bold'), command=fun1_tr3)
                tr3_button_1.grid(row=10, column=6, sticky='se', padx=25, pady=20)
            except Exception as e:
                wrong(f"颜色配置窗口出错: {e}")

        # 配置重复选项
        def fun4_tr():
            """
            配置重复选项的功能。
            """
            try:
                l_trunk_4 = tk.Toplevel()
                l_trunk_4.resizable(False, False)
                l_trunk_4.title('重复')
                l_trunk_4.iconbitmap('icon_trunk.ico')

                # 显示当前设置
                if pass_move:
                    tr4_label_1 = tk.Label(l_trunk_4, text='目前：不重复', font=('楷体', pass_size + 8, 'bold'))
                else:
                    tr4_label_1 = tk.Label(l_trunk_4, text='目前：重复', font=('楷体', pass_size + 8, 'bold'))
                tr4_label_1.grid(row=1, column=1)

                # 创建选择框
                tr4_listbox_1 = tk.Listbox(l_trunk_4, width=15, height=2, font=('楷体', pass_size + 5, 'bold'))
                tr4_listbox_1.grid(row=2, column=1)
                tr4_listbox_1.insert(0, '不重复')
                tr4_listbox_1.insert(1, '重复')

                def fun1_tr4():
                    global pass_move
                    selection = tr4_listbox_1.curselection()
                    if selection:
                        index = selection[0]
                        if index == 0:
                            pass_move = True
                            tr4_label_1.config(text='目前：不重复')
                        else:
                            pass_move = False
                            tr4_label_1.config(text='目前：重复')
                    l_trunk_4.destroy()

                tr4_button_1 = tk.Button(l_trunk_4, text='确定', font=('楷体', pass_size, 'bold'), command=fun1_tr4)
                tr4_button_1.grid(row=3, column=2, sticky='se', padx=15, pady=10)
            except Exception as e:
                wrong(f"重复配置窗口出错: {e}")

        # 保存配置
        def fun5_tr():
            """
            保存配置的功能。
            """
            try:
                trunk__ = tk.Toplevel()
                trunk__.geometry('430x240+400+250')
                trunk__.resizable(False, False)
                trunk__.title('保存')
                tr__label = tk.Label(trunk__, text='保存更改？', font=('楷体', pass_size + 5, 'bold'))
                tr__label.grid(row=1, column=1)

                def fun__2():
                    trunk__.destroy()
                    trunk.destroy()

                def fun__1():
                    save_configuration()
                    trunk__.destroy()
                    trunk.destroy()
                    clear_window()
                    tr__label_ = tk.Label(root, text='请重启', font=('楷体', pass_size + 30, 'bold'))
                    tr__label_.grid(row=0, column=0, sticky="nsew")
                    root.grid_rowconfigure(0, weight=1)
                    root.grid_columnconfigure(0, weight=1)
                    root.destroy()
                    app()

                tr__button_1 = tk.Button(trunk__, text='是', font=('楷体', pass_size + 3, 'bold'), command=fun__1)
                tr__button_1.grid(row=2, column=1)
                tr__button_1 = tk.Button(trunk__, text='否', font=('楷体', pass_size + 3, 'bold'), command=fun__2)
                tr__button_1.grid(row=2, column=2)
            except Exception as e:
                wrong(f"保存配置窗口出错: {e}")

        try:
            l_button_trunk.append(
                tk.Button(trunk, text='随机内容', font=('楷体', pass_size + 5, 'bold'), command=fun1_tr))
            l_button_trunk.append(
                tk.Button(trunk, text='文字大小', font=('楷体', pass_size + 5, 'bold'), command=fun2_tr))
            l_button_trunk.append(
                tk.Button(trunk, text='文字颜色', font=('楷体', pass_size + 5, 'bold'), command=fun3_tr))
            l_button_trunk.append(
                tk.Button(trunk, text='内容重复', font=('楷体', pass_size + 5, 'bold'), command=fun4_tr))
            l_button_trunk.append(tk.Button(trunk, text='确定', font=('楷体', pass_size, 'bold'), command=fun5_tr))
            for i in range(4):
                l_button_trunk[i].grid(row=i + 1, column=0)
            l_button_trunk[4].grid(row=5, column=4, sticky='se', padx=50, pady=20)
        except Exception as e:
            wrong(f"配置窗口按钮创建出错: {e}")

    trunk_button = tk.Button(root, text='配置', font=('楷体', pass_size + 5, 'bold'), command=trunk_set)
    trunk_button.grid(row=9, column=1)

    root.mainloop()

app()